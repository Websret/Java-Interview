java -jar con4md.jar --marker="##" $@
